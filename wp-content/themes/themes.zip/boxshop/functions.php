<?php 
/*** Options Framework ***/
require_once get_template_directory().'/admin/index.php';

/*** Include Framework File ***/
require_once get_template_directory().'/framework/init.php';	
?>